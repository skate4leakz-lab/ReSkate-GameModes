RESKATE GAME MODES  (built on ReSkate 1.1.6)
=============================================

Skate 3's online modes in skate. with ReSkate, plus a THPS-style Graffiti mode and
a Skate 2-style Bone Cam:

  SPOT JAM      Land lines inside the area. Highest total score wins.
  1-UP          Take turns. Beat the last score or take a strike. Last one standing wins.
  HALL OF MEAT  Bail as hard as you can. Most meat wins. Comes with the Bone Cam.
  DEATHRACE     Hit every checkpoint in order. First to the last one wins.
  DOMINATION    Take spots with your best line there. Holding them scores every second.
  GRAFFITI      Land a line in a zone to tag it in your colour. A bigger line steals it.

The player who starts a game marks out the play area (and any checkpoints or spots)
by riding to each place. Everyone in the lobby who has this mod joins automatically.


INSTALL
-------
1. Close the game and the ReSkate launcher.
2. Put this "ReSkate Game Modes" folder inside your ReSkate folder
   (the folder with Skate.exe and ReSkateLauncher.exe).
3. Double-click Install.bat.
   - Your original ReSkate.dll is kept as ReSkate.dll.original.
   - Launcher auto-updates are turned off, so the launcher doesn't replace this version.
   If the folder is somewhere else, Install.bat asks you to pick your ReSkate folder.

To remove it, double-click Uninstall.bat. That puts your original ReSkate.dll back and
turns updates on again.


PLAY
----
Start ReSkate as usual. In game, press Insert to open the ReSkate menu and pick
GAME MODES:
  - Pick a mode and press SET UP.
  - Ride to each corner of your spot and press ADD CORNER HERE (3 or more corners).
  - Deathrace / Domination: ride to each checkpoint or spot and press ADD HERE.
  - Press START GAME. Everyone gets a 5 second countdown.

The same things work from the console (the ` key): type  mode help


BONE CAM
--------
When you bail in Hall of Meat, the screen goes X-ray: your skeleton is drawn over your
skater, the bones that took the hardest hits crack and turn red, and your injuries are
listed. Choose HALL OF MEAT, EVERY BAIL or OFF on the GAME MODES page, or press
PREVIEW BONE CAM to see it standing still.
When you play alone, the Bone Cam also slows the game down. In a lobby it never changes
game speed, because servers flag players who do.


GOOD TO KNOW
------------
- Players without this mod can still join your lobby and you can join theirs. They just
  don't take part in the games.
- Everything else is ReSkate 1.1.6 as normal: maps, mods, Thunderstore, Trainer,
  throwdowns, multiplayer.
- Trick scores come from ReSkate's own measurement of each jump (air time, height,
  distance, spins, flips). Grinds and manuals don't score yet.
- When ReSkate releases a new version, this one stays on 1.1.6 until it is rebuilt.
  Uninstall first if you want the official update.
- Mods that change trick scoring or physics keep you out of games in a lobby, the same
  as ReSkate's own throwdowns.


CREDITS AND LICENCE
-------------------
ReSkate by Dingo-Shenanigans: https://github.com/Dingo-Shenanigans/ReSkate
This is a modified version of ReSkate. Like ReSkate, it is licensed under the GNU GPL v3
(LICENSE.txt). Its source code is in the source zip released next to this one.

Bone Cam skeleton art: public domain, by Mikael Haggstrom and LadyofHats (Mariana Ruiz
Villarreal), from Wikimedia Commons ("Human skeleton front - no labels.svg").
