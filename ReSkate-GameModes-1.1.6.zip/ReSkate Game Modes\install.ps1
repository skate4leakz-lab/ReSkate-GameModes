# ReSkate Game Modes installer.
# Puts this folder's ReSkate.dll into your ReSkate folder (keeping your original as
# ReSkate.dll.original) and turns off the launcher's auto-updates so it is not replaced.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-ReSkate([string]$dir) {
    $dir -and (Test-Path -LiteralPath (Join-Path $dir 'Skate.exe')) -and (Test-Path -LiteralPath (Join-Path $dir 'ReSkateLauncher.exe'))
}

Write-Host ''
Write-Host '  ReSkate Game Modes installer' -ForegroundColor Yellow
Write-Host ''

# Where ReSkate is: this folder's parent (if you put this folder inside it), or you pick it.
$target = $null
foreach ($candidate in @((Split-Path $here -Parent), $here)) {
    if (Test-ReSkate $candidate) { $target = $candidate; break }
}
if (-not $target) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Pick your ReSkate folder (the one with Skate.exe and ReSkateLauncher.exe)'
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host 'Cancelled.'; exit 1 }
    $target = $dialog.SelectedPath
}
if (-not (Test-ReSkate $target)) {
    Write-Host "That folder has no Skate.exe and ReSkateLauncher.exe: $target" -ForegroundColor Red
    exit 1
}
if (Get-Process -Name Skate, ReSkateLauncher -ErrorAction SilentlyContinue) {
    Write-Host 'Close the game and the ReSkate launcher first, then run this again.' -ForegroundColor Red
    exit 1
}

$dll = Join-Path $target 'ReSkate.dll'
$backup = Join-Path $target 'ReSkate.dll.original'
if ((Test-Path -LiteralPath $dll) -and -not (Test-Path -LiteralPath $backup)) {
    Copy-Item -LiteralPath $dll -Destination $backup
    Write-Host "Your original ReSkate.dll is saved as ReSkate.dll.original"
}
Copy-Item -LiteralPath (Join-Path $here 'ReSkate.dll') -Destination $dll -Force
Write-Host "Installed ReSkate Game Modes into $target" -ForegroundColor Green

# Launcher auto-updates would put the official ReSkate.dll back.
$settingsPath = Join-Path $target 'ReSkateLauncher.settings.json'
try {
    if (Test-Path -LiteralPath $settingsPath) {
        $settings = Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
        if ($settings.PSObject.Properties.Name -contains 'updates') { $settings.updates = $false }
        else { $settings | Add-Member -NotePropertyName updates -NotePropertyValue $false }
    } else {
        $settings = [pscustomobject]@{ updates = $false }
    }
    $json = $settings | ConvertTo-Json -Depth 5
    [IO.File]::WriteAllText($settingsPath, $json, (New-Object Text.UTF8Encoding $false))
    Write-Host 'Launcher auto-updates turned off (turn them back on by running Uninstall.bat).'
} catch {
    Write-Host 'Could not change the launcher settings. In the ReSkate launcher, turn off "Updates" yourself.' -ForegroundColor Yellow
}
Write-Host ''
Write-Host 'Start ReSkate as usual, press Insert in game and open GAME MODES.' -ForegroundColor Yellow
