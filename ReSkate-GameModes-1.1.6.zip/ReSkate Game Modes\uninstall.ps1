# ReSkate Game Modes uninstaller: puts your original ReSkate.dll back and turns launcher updates on.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-ReSkate([string]$dir) {
    $dir -and (Test-Path -LiteralPath (Join-Path $dir 'Skate.exe')) -and (Test-Path -LiteralPath (Join-Path $dir 'ReSkateLauncher.exe'))
}

$target = $null
foreach ($candidate in @((Split-Path $here -Parent), $here)) {
    if (Test-ReSkate $candidate) { $target = $candidate; break }
}
if (-not $target) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Pick your ReSkate folder (the one with Skate.exe and ReSkateLauncher.exe)'
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host 'Cancelled.'; exit 1 }
    $target = $dialog.SelectedPath
}
if (Get-Process -Name Skate, ReSkateLauncher -ErrorAction SilentlyContinue) {
    Write-Host 'Close the game and the ReSkate launcher first, then run this again.' -ForegroundColor Red
    exit 1
}
$backup = Join-Path $target 'ReSkate.dll.original'
if (Test-Path -LiteralPath $backup) {
    Move-Item -LiteralPath $backup -Destination (Join-Path $target 'ReSkate.dll') -Force
    Write-Host 'Your original ReSkate.dll is back.' -ForegroundColor Green
} else {
    Write-Host 'No ReSkate.dll.original found. Turning updates on lets the launcher download the official one.' -ForegroundColor Yellow
}
$settingsPath = Join-Path $target 'ReSkateLauncher.settings.json'
if (Test-Path -LiteralPath $settingsPath) {
    $settings = Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
    if ($settings.PSObject.Properties.Name -contains 'updates') { $settings.updates = $true }
    [IO.File]::WriteAllText($settingsPath, ($settings | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding $false))
    Write-Host 'Launcher auto-updates turned back on.'
}
